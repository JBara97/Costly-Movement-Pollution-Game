Two cost with fixed strategies
T=200
N=50
D=[10,20,30,40]
R=5
phi=5
L = 50
runs=50
mu_rich=np.arange(0,1.05,0.05)

80% of agents are poor, 20% are rich

pcp is the per-capita-pollution over the entire population
pcp_type breaks it down by type & wealth:
	[0,0] = poor cooperator
	[0,1] = poor defector
	[1,0] = rich cooperator
	[1,1] = rich defector
