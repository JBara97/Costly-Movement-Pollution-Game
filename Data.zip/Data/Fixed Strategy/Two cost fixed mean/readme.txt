Two cost with fixed strategies and fixed mean
T=100
N=50
D=[10,20,30,40]
R=5
phi=5
L = 50
runs=50
mu_minority=np.arange(0,1.05,0.05)
4mu_majority + mu_minority = 2 (so that mean mu is 0.4)

80% of agents are majority, 20% are minority

pcp is the per-capita-pollution over the entire population
pcp_type breaks it down by type & wealth:
	[0,0] = poor cooperator
	[0,1] = poor defector
	[1,0] = rich cooperator
	[1,1] = rich defector
