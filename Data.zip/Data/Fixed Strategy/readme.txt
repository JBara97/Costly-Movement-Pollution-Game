Fixed Strategy experiments - i.e. epsilon = M_nu = 0
	T = 200
	N = 50
	R = 5
	phi = 5
	L = 50
	D = [10,20,30,40]
	mu = [0.25, 0.5, ..., 2.25, 2.5]

pcp is pcp_T - pcp_0
pcp.shape = (len(D),len(mu),runs)

CC is clusters; CC.shape = (len(D),len(mu),2,runs)
CC[:,:,0,:] is the number of clusters
CC[:,:,1,:] is the mean size of cluster
50 runs

a - 10 runs
b - 20 runs
c - 20 runs
all - a+b+c

d - 50 runs with mu = [0.05,0.1,0.15,0.2]
e - 50 runs with mu = [0.001,0.01]
-----------------------------------
FIN:
T=50, N=50, R=5, phi=5,L=50,D=[N//5,2N//5,3N//5,4N//5]
mu = np.arange(0,1.05,0.05),runs=50

FIN_zoom:
T=50, N=50, R=5, phi=5,L=50,D=[N//5,2N//5,3N//5,4N//5]
mu = np.arange(0,0.31,0.01),runs=50
