L = 50
runs = 200
T = 50

c_rate in the folders are NUMBERS of cooperators NOT fractions!

In this folder any "_all" has combined all the different densities together ie N=20,50,80
c_rate_all is a fraction!

When L=100, only 100 runs were ran, at a mu precision of 0.1 instead of 0.05
